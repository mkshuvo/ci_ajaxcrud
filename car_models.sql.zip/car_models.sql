-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 29, 2020 at 03:23 PM
-- Server version: 5.7.24
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ajax_crud_application`
--

-- --------------------------------------------------------

--
-- Table structure for table `car_models`
--

CREATE TABLE `car_models` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` double(10,2) NOT NULL,
  `transmission` enum('Automatic','Manual') NOT NULL,
  `Color` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `car_models`
--

INSERT INTO `car_models` (`id`, `name`, `price`, `transmission`, `Color`, `created_at`, `updated_at`) VALUES
(70, 'Mohsin Khan Shuvo', 123123.00, 'Manual', '123123', '2020-08-28 14:38:18', '0000-00-00 00:00:00'),
(71, 'snakelab', 123123.00, 'Manual', '123123', '2020-08-28 14:54:32', '0000-00-00 00:00:00'),
(72, 'coeluso', 1231.00, 'Automatic', '12212', '2020-08-28 14:55:19', '0000-00-00 00:00:00'),
(73, 'eudora', 24354.00, 'Manual', 'red', '2020-08-28 14:56:17', '0000-00-00 00:00:00'),
(74, 'eudora', 1223.00, 'Manual', 'color', '2020-08-29 14:27:52', '0000-00-00 00:00:00'),
(75, 'eudora', 1231.00, 'Manual', 'color', '2020-08-29 14:29:33', '0000-00-00 00:00:00'),
(76, 'Mohsin Khan', 123123.00, 'Automatic', '123123', '2020-08-29 14:32:27', '0000-00-00 00:00:00'),
(77, 'Mohsin Khan Shuvo', 24354.00, 'Manual', 'red', '2020-08-29 14:33:37', '0000-00-00 00:00:00'),
(78, 'Mohsin Khan Shuvo', 123123.00, 'Manual', 'color', '2020-08-29 14:34:57', '0000-00-00 00:00:00'),
(79, 'Mohsin Khan Shuvo', 12435.00, 'Manual', 'green', '2020-08-29 15:08:08', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car_models`
--
ALTER TABLE `car_models`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `car_models`
--
ALTER TABLE `car_models`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
